Acknowledgements
----------------

The Braintree SDK uses code from the following libraries:

* [phpunit](https://github.com/sebastianbergmann/phpunit), BSD-3-Clause License
