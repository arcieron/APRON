/* @flow */

if (window.xprops.onInit) {
    window.xprops.onInit();
}
