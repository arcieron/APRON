/* @flow */

export type QRCodeProps = {|
    qrPath : string,
    cspNonce : ?string
|};
