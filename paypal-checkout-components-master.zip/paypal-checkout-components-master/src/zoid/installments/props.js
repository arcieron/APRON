/* @flow */

export type InstallmentsProps = {|
    nonce : string
|};
